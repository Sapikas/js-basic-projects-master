//using selectors inside the element
